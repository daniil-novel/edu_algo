#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

struct Person {
    int index {};
    char language {};
    int barrier {};
    int chain {};

    friend ostream& operator<<(ostream& os, Person& p) {
        os << "index " << p.index << " {" 
           << " language: " << p.language
           << ", barrier: " << p.barrier
           << ", chain: " << p.chain
           << " }";

        return os;
    }
};

vector<Person*> hierarchy;
vector<Person*> person_list;

template<typename T>
ostream& operator<<(ostream& os, vector<T*>& v) {
    for(auto *x : v) {
        os << *x << endl;
    }

    return os;
}   

bool sameLanguage(Person* p1, Person* p2) {
    return p1->language == p2->language || !p1->language || !p2->language;
}

void DFSNoRecursion() {
    vector<Person*> person_stack(person_list.size());
    person_stack[0] = person_list[0];

    int depth = 0;
    cout << depth << endl;

    for(Person *next : hierarchy) {
        if(person_stack[depth] == next) {
            if(depth) depth--; 
        } else {
            Person *current = person_stack[depth];

            depth++;
            person_stack[depth] = next; 

            next->chain = sameLanguage(current, next) ? current->chain + 1 : 1;
            next->barrier = next->chain > 1 ? 0 : current->chain;
            
            cout << string(depth, '*') << next->index << endl;
        }
    }
}

void printBarrier() {
    for(int i = 1; i < person_list.size(); i++) {
        cout << person_list[i]->barrier << " ";
    }
    cout << endl;
}

void init() {
    string filename = "data.txt";
    ifstream fin{filename};

    int n_employee;
    fin >> n_employee;

    int n_person = n_employee + 1;

    person_list.resize(n_person);

    Person *person = new Person;
    person->language = 0;
    person->index = 0;

    person_list[0] = person;

    for(int i = 1; i < n_person; i++) {
        Person *person = new Person;

        fin >> person->language;
        person->index = i;

        person_list[i] = person;
    }

    hierarchy.resize(2 * n_person);
    for(int i = 0; i < 2 * n_person; i++) {
        int person_index;
        fin >> person_index;

        hierarchy[i] = person_list[person_index];
    }

    fin.close();
}


int main() {
    init();
    DFSNoRecursion();

    printBarrier();
    return 0;
}
