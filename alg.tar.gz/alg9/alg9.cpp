#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>

using namespace std;

int n_person {};

vector<char> languages;
vector<int> hierarchy;
vector<int> barrier;

template<typename T>
ostream& operator<<(ostream& os, vector<T>& v) {
    for(auto x : v) {
        os << x << " ";
    }

    return os << endl;
}   

void DFS() {
}

void init() {
    string filename = "data.txt";
    ifstream fin{filename};

    fin >> n_person;

    languages.resize(n_person + 1);
    for (int i = 1; i <= n_person; i++) {
        fin >> languages[i];
    }

    hierarchy.resize(2 * (n_person + 1));
    for (int i = 0; i < 2 * (n_person + 1); i++) {
        fin >> hierarchy[i];
    }

    barrier.resize(n_person + 1);

    fin.close();
}

int main() {
    init();
    DFS();

    cout << barrier;
    
    return 0;
}
