from random import choice, randint, random


n_employee_max = 40
n_employee_min = 20
nfile_begin = 15
nfile_end = 15

max_children = (0, 3)  # Максимальное количество детей у каждого узла (мин, макс)
max_depth = (3, 5)     # Максимальная глубина дерева (мин, макс)


#TODO
def DFS(f, n_person, depth):
    min_child, max_child = max_children
    min_depth, max_depth = depth

    if min_depth < max_depth:
        person = n_person
        child_count = randint(min_child, max_child)

        while child_count > 0 and min_depth < max_depth:
            print(person, file=f, end=" ")

            next_depth = min_depth + 1
            if random() < 0.5:  # Шанс остановки создания детей
                next_child_count = randint(min_child, max_child)
                DFS(f, n_person + 1, (next_depth, max_depth))
            else:
                next_child_count = 0

            child_count -= 1


def printTree(person_stack, child_count_stack):
    hierarchy_levels = len(person_stack)
    for i in range(hierarchy_levels):
        print('*' * i, person_stack[i], sep='', end=" ")
        if i < hierarchy_levels - 1:
            print(f"({child_count_stack[i]})", end=" ")
    print()


for f in range(nfile_begin, nfile_end + 1):
    filename = f"data{f}.txt"
    with open(filename, "w") as f:
        n_employee = randint(n_employee_min, n_employee_max)
        print(n_employee)

        for _ in range(n_employee):
            print(choice("AB"), file=f, end=" ")
        print()

        n_person = 0
        DFS(f, n_person, max_depth)

        # Вывод дерева на консоль
        printTree(list(range(n_person)), [0] * n_person)

