from random import choice, randint, random, shuffle

n_employee_max = 40
n_employee_min = 20

nfile_begin = 15
nfile_end = 15


def DFS(f, n_person):
    person_stack = []
    child_count_stack = []
    free_person = 0

    while person_stack or free_person == 0:
        go_up = random() < 0.5 and len(person_stack) > 1 or free_person >= n_person
        if go_up:
            person = person_stack.pop()
            child_count = child_count_stack.pop()
            printChildren(child_count_stack, child_count);
        else:
            person = free_person
            person_stack.append(person)
            free_person += 1 

            if len(child_count_stack) > 0:
                child_count_stack[-1] += 1
            child_count_stack.append(0)

            printTree(person_stack)

        print(person, file = f, end = " ")

        

def printChildren(child_count_stack, child_count): 
    print('\x1b[31m', end = "")
    print(f"{'*' * len(child_count_stack)}{child_count}")
    print('\x1b[0m', end = "")


def printTree(person_stack):
    print('*' * (len(person_stack) - 1), person_stack[-1], sep = "")


for f in range(nfile_begin, nfile_end + 1):
    filename = f"data{f}.txt"
    f = open(filename, "w")

    n_employee = randint(n_employee_min, n_employee_max)
    print(n_employee, file = f)

    for _ in range(n_employee):
        print(choice("AB"), file = f, end = " ")
    print(file = f)
    
    n_person = n_employee + 1;
    print(n_person)
    DFS(f, n_person)

    f.close()
        
