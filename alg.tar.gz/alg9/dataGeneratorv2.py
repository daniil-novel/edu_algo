from random import choice, randint, random


class Person:
    def __init__(self, person_id, child_count = 0):
        self.id = person_id
        self.child_count = child_count


PersonStack = list

def DFS(f, n_person):
    stack = PersonStack()
    free_person_id = 0

    while stack or free_person_id == 0:
        go_up = random() < 0.5 and len(stack) > 1 or free_person_id >= n_person
        if go_up:
            person = stack.pop()

            printChildren(stack)
        else:
            if len(stack) > 0:
                stack[-1].child_count += 1
                
            person = Person(person_id = free_person_id)
            stack.append(person)
            free_person_id += 1

            printTree(stack)
            
        print(person.id, file=f, end=" ")


def printChildren(stack):
    print('\x1b[31m', end = "")

    for person in stack:
        print('*' * 3, person.child_count, sep='', end="")

    print('\x1b[0m')



def printTree(stack):
    for person in stack:
        print('*' * 3, person.id, sep='', end="")
    print()


n_employee_max = 30
n_employee_min = 20
nfile_begin = 3
nfile_end = 5

for f in range(nfile_begin, nfile_end + 1):
    filename = f"data{f}.txt"
    with open(filename, "w") as f:
        n_employee = randint(n_employee_min, n_employee_max)
        print(n_employee, file=f)

        for _ in range(n_employee):
            print(choice("AB"), file=f, end=" ")
        print(file=f)

        n_person = n_employee + 1
        print(n_person)
        DFS(f, n_person)
