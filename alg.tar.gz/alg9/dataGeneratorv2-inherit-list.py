from random import choice, randint, random


class Person:
    def __init__(self, id, language=None, hierarchy=None, barrier=None):
        self.id = id
        self.language = language
        self.hierarchy = hierarchy
        self.barrier = barrier


class StackPerson(list):
    def __init__(self, iterable = ()):
        super().__init__(iterable) 

    def push(self, person):
        self.append(person)

    def top(self):
        if self:
            return self[-1]


def DFS(f, n_person):
    person_stack = StackPerson()
    child_count_stack = []

    for i in range(n_person):
        person = Person(i)
        if i > 0:
            if random() < 0.5:
                while child_count_stack and child_count_stack[-1] == 2:  # проверка на пустоту
                    person_stack.pop()  # возвращаемся к предыдущему родителю
                    child_count_stack.pop()
                if child_count_stack:
                    child_count_stack[-1] += 1
                else:
                    child_count_stack.append(1)  # если child_count_stack пустой, добавляем первого ребенка
            else:
                child_count_stack.append(0)
        person_stack.push(person)
        print(person.id, file=f, end=" ")
        printTree(person_stack, child_count_stack)


def printTree(person_stack, child_count_stack):
    hierarchy_levels = len(person_stack)
    for i in range(hierarchy_levels):
        print('*' * i, person_stack[i].id, sep='', end=" ")
        if i < len(child_count_stack):  # наличие элемента в child_count_stack
            print(f"({child_count_stack[i]})", end=" ")
    print()



n_employee_max = 10
n_employee_min = 2
nfile_begin = 3
nfile_end = 9

for f in range(nfile_begin, nfile_end + 1):
    filename = f"data{f}.txt"
    with open(filename, "w") as f:
        n_employee = randint(n_employee_min, n_employee_max)
        print(n_employee, file=f)

        for _ in range(n_employee):
            print(choice("AB"), file=f, end=" ")
        print(file=f)

        n_person = n_employee + 1
        print(n_person)
        DFS(f, n_person)
