from random import choice, randint, random

child_count_range = (0, 3)
max_depth_range = (10, 20)

class Person:
    def __init__(self, person_id, child_count = 0):
        self.id = person_id
        self.child_count = child_count
        self.child_count_max = randint(*child_count_range)


PersonStack = list

def DFS(f, n_person):
    stack = PersonStack()
    free_person_id = 0

    while stack or free_person_id == 0:
        max_depth = randint(*max_depth_range)
        go_up = len(stack) > 1 and \
                stack[-1].child_count == stack[-1].child_count_max or \
                free_person_id >= n_person or \
                len(stack) >= max_depth 
        if go_up:
            person = stack.pop()

            printChildren(stack)
        else:
            if len(stack) > 0:
                stack[-1].child_count += 1
                
            person = Person(person_id = free_person_id)
            stack.append(person)
            free_person_id += 1

            printTree(stack)
            
        print(person.id, file=f, end=" ")


def printChildren(stack):
    print('\x1b[31m', end = "")

    for person in stack:
        print('*' * 3, person.child_count, sep='', end="")

    print('\x1b[0m')



def printTree(stack):
    for person in stack:
        print('*' * 3, person.id, sep='', end="")
    print()


n_employee_max = 300
n_employee_min = 200
nfile_begin = 3
nfile_end = 3

for f in range(nfile_begin, nfile_end + 1):
    filename = f"data{f}.txt"
    with open(filename, "w") as f:
        n_employee = randint(n_employee_min, n_employee_max)
        print(n_employee, file=f)

        for _ in range(n_employee):
            print(choice("AB"), file=f, end=" ")
        print(file=f)

        n_person = n_employee + 1
        print(n_person)
        DFS(f, n_person)
