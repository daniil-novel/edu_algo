#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <algorithm>

using namespace std;

int n_vertex;
int m_edge;
int k_operation;

struct Command;
using Commandlist = vector<Command>;
using Answerlist = vector<string>;

template<typename T>
ostream& operator<<(ostream& os, const vector<T>& v) {
    for(const T& t : v) {
        os << t;
    }

    return os;
}

namespace Vertex {

    vector<int> parent;
    vector<int> size;

    int findRoot(int v) {
        if (v == parent[v]) {
            return v;
        }
        return parent[v] = findRoot(parent[v]);
    }

    bool ask(int u, int v) {
        return (findRoot(u) == findRoot(v));
    }

    void merge(int u, int v) {
        u = findRoot(u);
        v = findRoot(v);

        if(u != v) {
            if(size[u] < size[v]) {
                swap(u, v);
            }

            parent[v] = u;
            size[u] += size[v];
        }
    }

}

struct Command {
    string name;
    int ui, vi; // индексы двух вершин, к которым относится команда

    friend ostream& operator<<(ostream& os, const Command& cmd) {
        os << cmd.name << " " << cmd.ui << " -> " << cmd.vi << endl;
        return os;
    }

    friend istream& operator>>(istream& is, Command& cmd) {
        return is >> cmd.name >> cmd.ui >> cmd.vi;
    }
};

Commandlist commandlistInit(ifstream& fin) {
    Commandlist commands;
    for(int i = 0; i < k_operation; i++) {
        Command cmd;
        fin >> cmd;

        commands.push_back(cmd);
    }

    reverse(commands.begin(), commands.end());

    return commands;
}

void vertexlistInit() {
    // Поскольку изнач. каждая вершина прин. к отдельному множ., размер будет n_vertex + 1 для инд. с ед
    Vertex::parent.resize(n_vertex + 1); 
    //Заполняем 1, так как изначально все множества состоят из 1 вершины
    Vertex::size.assign(n_vertex + 1, 1); 
    for (int i = 1; i <= n_vertex; ++i) {
        Vertex::parent[i] = i;
    }
}

void init(Commandlist& reversed_commandlist) {
    string filename = "data8.txt";
    ifstream fin{filename};

    fin >> n_vertex >> m_edge >> k_operation;
//    cout << n_vertex << " " << m_edge << " " << k_operation << endl;

    for(int i = 0; i < m_edge; i++) {
        int ui, vi;

        fin >> ui >> vi;
    }

}
    reversed_commandlist = commandlistInit(fin);

Answerlist execute(Commandlist& reversed_commandlist) {
    Answerlist anslst;
    for(auto cmd : reversed_commandlist) {
        if(cmd.name == "cut") {
            Vertex::merge(cmd.ui, cmd.vi);
        } else {
            anslst.push_back(Vertex::ask(cmd.ui, cmd.vi) ? "YES\n" : "NO\n");
        }
    }
    return anslst;
}

int main() {
    Commandlist reversed_commandlist;
    init(reversed_commandlist);
    vertexlistInit();
    Answerlist answerlist = execute(reversed_commandlist);

    cout << answerlist;
} 
