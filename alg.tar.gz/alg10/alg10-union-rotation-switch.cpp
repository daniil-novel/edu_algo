#include <iostream>
#include <fstream>
#include <vector>
#include <array>

using namespace std;

constexpr int ROWS = 8; // Количество строк
constexpr int COLS = 8; // Количество столбцов

array<array<bool, COLS>, ROWS> occupied;

union Position {
    unsigned char byte;
    struct {
        unsigned r : 2;
        unsigned x : 3;
        unsigned y : 3;
    } param;
};

template<typename T>
ostream& operator<<(ostream& os, const vector<T>& v) {
    for(const T& t : v) {
        os << t << endl;
    }
    return os << endl;
}

template<typename T, size_t N, size_t M>
ostream& operator<<(ostream& os, const array<array<T, M>, N>& matrix) {
    for(const auto& row : matrix) {
        for(const auto cell : row) {
            os << cell;
        }
        os << endl;
    }
    return os;
}

bool inField(char x, char y) {
    return x < COLS && y < ROWS && x >= 0 && y >= 0; 
}

bool isFree(char x, char y) {
    return inField(x, y) && !occupied[y][x];
}

bool checkPosition(char x, char y, char r) {
    if (occupied[y][x]) return 0; 

    switch (r % 4) {
        case 0: // 0 ┬
            return isFree(x + 1, y) && isFree(x - 1, y) && isFree(x, y + 1); 
        case 1: // 90 ├
            return isFree(x + 1, y) && isFree(x, y - 1) && isFree(x, y + 1); 
        case 2: // 180 ┴
            return isFree(x + 1, y) && isFree(x - 1, y) && isFree(x, y - 1); 
        case 3: // 270 ┤
            return isFree(x - 1, y) && isFree(x, y - 1) && isFree(x, y + 1); 
    }

    return 1;
}

int calculate() {
    int arranged_count = 0;
    for(Position pos {0};; pos.byte++) {
//        cout << pos.param.x << " " << pos.param.y << " " << pos.param.r << endl; 

        arranged_count += checkPosition(pos.param.x, pos.param.y, pos.param.r);
        
        if(pos.byte == 255) break;
    }
    return arranged_count;
}

void init(const string& filename) {
    ifstream fin(filename);

    for(auto& row : occupied) {
        for(auto& cell : row) {
            char ch;
            fin >> ch;
            cell = ch == '*';
        }
    }
//    cout << occupied;

    fin.close();
}

int main(int argc, char **argv) {
    string filename {argc > 1 ? argv[1] : "data.txt"};

    init(filename);
    cout << calculate();

    return 0;
}

