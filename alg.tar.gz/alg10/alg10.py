from itertools import islice, product

ROWS = 8
COLS = 8

def init(filename):
    global occupied
    occupied = []

    f = open(filename)
    for row in islice(f, ROWS):
        occupied.append([c == '*' for c in row.strip()])

#    print(occupied)
    return occupied

def in_field(x, y):
    return 0 <= x < COLS and 0 <= y < ROWS

def is_free(x, y):
    return in_field(x, y) and not occupied[y][x]

def check_position(x, y, r):
    if occupied[y][x]: return False

    if r % 4 == 0:  # 0 ┬
        return is_free(x + 1, y) and is_free(x - 1, y) and is_free(x, y + 1)
    elif r % 4 == 1:  # 90 ├
        return is_free(x + 1, y) and is_free(x, y - 1) and is_free(x, y + 1)
    elif r % 4 == 2:  # 180 ┴
        return is_free(x + 1, y) and is_free(x - 1, y) and is_free(x, y - 1)
    elif r % 4 == 3:  # 270 ┤
        return is_free(x - 1, y) and is_free(x, y - 1) and is_free(x, y + 1)

def calculate():
    arranged_count = 0
    for x, y, r in product(range(COLS), range(ROWS), range(4)):
        arranged_count += check_position(x, y, r)

    return arranged_count

def main():
    filename = "data.txt"
    init(filename)
    print(calculate())

if __name__ == "__main__":
    main()
