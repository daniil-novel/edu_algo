#include <iostream>
#include <fstream>
#include <vector>
#include <array>

using namespace std;

constexpr int ROWS = 8; // Количество строк
constexpr int COLS = 8; // Количество столбцов

array<array<bool, COLS>, ROWS> occupied;

template<typename T>
ostream& operator<<(ostream& os, const vector<T>& v) {
    for(const T& t : v) {
        os << t << endl;
    }
    return os << endl;
}

template<typename T, size_t N, size_t M>
ostream& operator<<(ostream& os, const array<array<T, M>, N>& matrix) {
    for(const auto& row : matrix) {
        for(const auto cell : row) {
            os << cell;
        }
        os << endl;
    }
    return os;
}

void init() {
    ifstream fin("data.txt");

    for(auto& row : occupied) {
        for(auto& cell : row) {
            char ch;
            fin >> ch;
            cell = ch == '*';
        }
    }
    cout << occupied;

    fin.close();
}

bool inField(char x, char y) {
    return x < COLS && y < ROWS && x >= 0 && y >= 0; 
}

bool isFree(char x, char y) {
    return inField(x, y) && !occupied[y][x];
}

bool checkPosition(char x, char y, char r) {
    if (occupied[y][x]) return 0; 

    static int dx[] {0, -1, 0, 1};
    static int dy[] {-1, 0, 1, 0};
    
    bool placeable = 1;
    for(int i = 0; i < 4; i++) {
        if(i == r) continue;
        placeable *= isFree(x + dx[i], y + dy[i]);
    }

    return placeable;
}

int calculate() {
    int placed_count = 0;
    for(int pos = 0; pos < 256; pos++) {
        char r = pos & 3;
        char x = (pos & 7 << 2) >> 2;
        char y = (pos & 7 << 5) >> 5;

//        cout << (int)y << (int)x << (int)r << endl;
        placed_count += checkPosition(x, y, r);
        
    }
    return placed_count;
}

int main() {
    init();
    cout << calculate();

    return 0;
}

