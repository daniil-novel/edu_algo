import tkinter as tk
from tkinter import ttk

root = tk.Tk()

root.title("data generator")
root.geometry("600x400")
root.columnconfigure(0, weight = 1)
root.rowconfigure(0, weight = 1)
root.bind("q", lambda e: root.destroy())

frm = ttk.Frame(root)
frm.configure(borderwidth = 4, relief = "sunken")
frm.columnconfigure(0, weight = 1)
frm.rowconfigure(0, weight = 1)
frm.grid(row = 0, column = 0, sticky = "news")

lbl = ttk.Label(frm)
lbl.configure(text = "test", background = "lightgreen", anchor = "center")
lbl.grid(row = 0, column = 0, sticky = "news")
lbl.bind("<1>", lambda e: lbl.configure(background = "lightblue" if str(lbl["background"]) == "lightgreen" else "lightgreen"))

root.mainloop()
