from random import choice

ROWS = 8  
COLS = 8  
nfile_min = 2  
nfile_max = 5

def generate_data(filename):
    with open(filename, "w") as f:
        for _ in range(ROWS):
            row = ''.join(choice('.*') for _ in range(COLS)) 
            print(row, file = f)

for i in range(nfile_min, nfile_max + 1):
    filename = f"data{i}.txt"
    generate_data(filename)
    print("Создан файл", filename)

