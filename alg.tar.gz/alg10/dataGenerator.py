import subprocess
import tkinter as tk
from tkinter import messagebox as msgbox
from tkinter import ttk

ROWS = 8
COLS = 8
STAR = "\u26b9"
DOT = "\u25e6"

def getFilename():
    return f"data{spb.get()}.txt"

def generate_data():
    filename = getFilename()
    with open(filename, "w") as f:
        for row in range(ROWS):
            for col in range(COLS):
                text = labels[row][col]["text"]
                print("*" if text == STAR else ".", end = "", file = f)
            print(file = f)

    status["text"] = f"File {filename} generated"

def on_label_click(event):
    label = event.widget
    current_text = label["text"]
    label["text"] = STAR if current_text == DOT else DOT
    label["foreground"] = "red" if label["text"] == STAR else "black"

    status["text"] = ""

def calculate():
    status["text"] = ""
    filename = getFilename()
#    process = subprocess.Popen(["./alg10-union-rotation-switch"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    result = subprocess.run(["./alg10-union-rotation-switch", filename], capture_output = 1, text = 1)
    if result.returncode == 0:
        msgbox.showinfo(
                message = f"Placement count: {result.stdout}    ",
                title = f"Calculate {filename}",
                icon = "info"
        )
#        status["text"] = f"Placement count: {result.stdout}"
    else:
        status["text"] = f"Error: {result.stderr}"

root = tk.Tk()
root.title("dataGenerator")
root.resizable(0, 0)
root.bind("q", lambda e: root.destroy())

frm = tk.Frame(root, padx = 10, pady = 10)
frm.grid(row = 0, column = 0, columnspan = 2)

frm_filenum = tk.Frame(root, padx = 10)
frm_filenum.grid(row = 1, column = 0, sticky = "w")

prelabel = tk.Label(frm_filenum, text = "Filename:  data")
prelabel.grid(row = 0, column = 0)

spb = tk.Spinbox(frm_filenum, width = 2, from_ = 0, to = 20, wrap = 1)
spb.grid(row = 0, column = 1)

postlabel = tk.Label(frm_filenum, text = ".txt")
postlabel.grid(row = 0, column = 2)

btn = tk.Button(root, text = "Generate", command = generate_data, padx = 40, pady = 10)
btn.grid(row = 1, column = 1, pady = 10, padx = 10, sticky = "e")
root.bind("g", lambda e: btn.invoke())

btn = tk.Button(root, text = "Calculate", command = calculate, padx = 40, pady = 10)
btn.grid(row = 2, column = 1, pady = 10, padx = 10, sticky = "e")
root.bind("g", lambda e: btn.invoke())

sep = ttk.Separator(root, orient = tk.HORIZONTAL)
sep.grid(row = 3, column = 0, columnspan = 2, sticky = "we")

status = tk.Label(root, padx = 10, anchor = "w")
status.grid(row = 4, column = 0, sticky = "we", columnspan = 2)


labels = []
for row in range(ROWS):
    row_labels = []
    for col in range(COLS):
        label = tk.Label(frm, text = DOT, width = 2, height = 1)
        label.configure(borderwidth = 1, relief = "solid", font = "Arial 25", anchor = "center")
        label.grid(row = row, column = col)
        label.bind("<Button-1>", on_label_click)
        row_labels.append(label)
    labels.append(row_labels)

root.mainloop()
