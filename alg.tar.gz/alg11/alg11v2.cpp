#include <iostream>
#include <string>
#include <fstream>

using namespace std;

void edit(string& str, const string& cmd, string::iterator& cursor, char c) {
    if(cmd == "delete") {
        if(cursor != str.end()) {
            str.erase(cursor);
        }
    } else if(cmd == "bspace") {
        if (cursor != str.begin()) {
            cursor = str.erase(cursor - 1);
        }
    } else if(cmd == "left") {
        if(cursor != str.begin()) {
            cursor--;  
        }
    } else if(cmd == "right") {
        if(cursor != str.end()) {
            cursor++; 
        }
    } else if(cmd == "insert") {
        str.insert(cursor++, c);
    }
}

string parse(const string& input) {
    string result;
    auto cursor = result.begin();
    bool tag = 0;
    string tag_buf;
    for(char c : input) {
        if(c == '<') {
            tag = 1;
        } else {
            if(tag) {
                if(c != '>') {
                    tag_buf.append(1, c);
                } else {
                    tag = 0;
                    edit(result, tag_buf, cursor, c);
                    tag_buf.clear();
                }
            } else {
                edit(result, "insert", cursor, c);
            }
        }

        string print_res = result;
        int pos = cursor - result.begin();
        print_res.insert(print_res.begin() + pos, '|');
        cout << "c: " << c << " result: " << print_res << " tag_buf: " << tag_buf << endl;
    }

    return result;
}

int main() {
    string expected, input;
    ifstream fin{"data.txt"};
    fin >> expected >> input;

    string result = parse(input);

    if (result == expected) {
        cout << "Yes";
    } else {
        cout << "No";
    }

    return 0;
}

