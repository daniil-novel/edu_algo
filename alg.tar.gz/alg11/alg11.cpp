#include <iostream>
#include <string>
#include <fstream>

using namespace std;

string parse(const string& input) {
    string result;
    auto cursor = result.begin();
    bool tag = 0;
    string tag_buf;
    for(char c : input) {
        if(c == '<') {
            tag = 1;
        } else {
            if(tag) {
                if(c != '>') {
                    tag_buf.append(1, c);
                } else {
                    tag = 0;

                    if(tag_buf == "delete") {
                        if(cursor != result.end()) {
                            result.erase(cursor);
                        }
                    } else if(tag_buf == "bspace") {
                        if (cursor != result.begin()) {
                            cursor = result.erase(cursor - 1);
                        }
                    } else if(tag_buf == "left") {
                        if(cursor != result.begin()) {
                            cursor--;  
                        }
                    } else if(tag_buf == "right") {
                        if(cursor != result.end()) {
                            cursor++; 
                        }
                    }

                    tag_buf.clear();
                }
            } else {
                result.insert(cursor++, c);
            }
        }

        string print_res = result;
        int pos = cursor - result.begin();
        print_res.insert(print_res.begin() + pos, '|');
        cout << "c: " << c << " result: " << print_res << " tag_buf: " << tag_buf << endl;
    }

    return result;
}

int main() {
    string expected, input;
    ifstream fin{"data2.txt"};
    fin >> expected >> input;

    string result = parse(input);

    if (result == expected) {
        cout << "Yes";
    } else {
        cout << "No";
    }

    return 0;
}

